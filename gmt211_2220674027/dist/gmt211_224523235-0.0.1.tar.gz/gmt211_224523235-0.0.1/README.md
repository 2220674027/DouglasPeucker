# GMT 211 - Douglas Peucker Algoritması

Bu kütüphane, Hacettepe Üniversitesi Geomatik Mühendisliği GMT 211 dersi kapsamında geliştirilmiştir. Herhangi bir üçüncü parti kütüphane (numpy, scipy vb.) kullanmadan saf Python ile Douglas-Peucker çizgi basitleştirme algoritmasını uygular.

## Kurulum

```bash
pip install --index-url [https://test.pypi.org/simple/](https://test.pypi.org/simple/) gmt211_224523235